plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
val ksPass: String? = System.getenv("KS_PASS")
android {
    namespace = "uz.nur.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "uz.nur.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    signingConfigs {
        if (ksPass != null) {
            create("rel") {
                storeFile = rootProject.file("release.keystore")
                storePassword = ksPass
                keyAlias = "suhbat"
                keyPassword = ksPass
            }
        }
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            if (ksPass != null) signingConfig = signingConfigs.getByName("rel")
        }
    }
    lint { checkReleaseBuilds = false }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
}
