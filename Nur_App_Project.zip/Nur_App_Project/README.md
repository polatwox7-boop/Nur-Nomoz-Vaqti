# Nur - Islomiy Portal (PWA)

Tojikiston va O'zbekiston shaharlari uchun namoz vaqtlari, namoz o'rganish qo'llanmasi (tahorat, rakatlar, o'qiladigan duolar) va Qur'on suralari.

## Fayllar
- `index.html` — ilovaning o'zi
- `sw.js` — oflayn ishlash uchun service worker
- `manifest.json`, `icon.svg`, `icon-192.png`, `icon-512.png` — bosh ekranga qo'shish uchun

## GitHub Pages orqali joylash
1. Barcha fayllarni GitHub'dagi repozitoriyga `main` branchga yuklang.
2. `Settings` -> `Pages` -> `Source` ni **GitHub Actions** qilib tanlang.
3. `.github/workflows/build.yml` faylini GitHub saytida yarating va Commit qiling. Shundan keyin `main` ga har bir push saytni avtomatik yangilaydi.
4. Telefonda saytni ochib, brauzer menyusidan **"Add to Home Screen"** ni bosing.

## Eslatma
Namoz vaqtlari Aladhan API orqali olinadi (Hanafiy mazhabi). Oxirgi yuklangan vaqtlar oflayn rejimda ham ko'rinadi.
