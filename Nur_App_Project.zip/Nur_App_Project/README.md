# Nur — Islomiy portal (PWA)

Namoz vaqtlari (Tojikiston va O‘zbekiston shaharlari), Qibla, namoz o‘rganish qo‘llanmasi, 114 sura (arabcha va o‘zbekcha tarjima) va tasbeh.

## GitHub Pages orqali joylash
1. Yangi repository oching (masalan `Nur-App`, **Public**).
2. Shu papkadagi hamma fayllarni yuklang: `index.html`, `sw.js`, `manifest.json`, `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`.
3. `Settings → Pages → Deploy from a branch → main → / (root) → Save`.
4. Telefonda saytni oching va brauzer menyusidan **Bosh ekranga qo‘shish** (yoki **Install**) ni tanlang.

## Eslatma
- Vaqtlar Aladhan API orqali hisoblanadi, sura matni Al-Quran Cloud API'dan olinadi. Bir marta yuklangan oylik jadval va ochilgan suralar internetsiz ham ishlaydi.
- Hisoblash usulini va daqiqalik tuzatishni sozlamalardan o‘zgartiring, mahalliy masjid jadvali bilan solishtiring.
